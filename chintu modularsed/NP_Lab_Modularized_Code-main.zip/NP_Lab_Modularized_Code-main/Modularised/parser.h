#ifndef PARSER_H
#define PARSER_H

#include "student.h"

void parseFile(char *input_filename);

#endif // PARSER_H
